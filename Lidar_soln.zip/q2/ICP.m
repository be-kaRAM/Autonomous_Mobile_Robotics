function [r,t] = ICP(scan1,scan2,iters,R_init,T_init,max_tresh)

alignment_threshold = 5.53*1e-4;
r = R_init;
t = T_init;
s1 = size(scan1);
s2= size(scan2);
scan1_m  =mean(scan1,2);  % mean of scan 1 points

for i = 1:iters
    scan2_t = r*scan2 + repmat(t,[1 , s2(2)]); % transformed scan2 wrt to scan1
    scan2_n = correspondence(scan1, scan2_t,max_tresh);
    
    scan2_m  =mean(scan2_n,2); % mean of transformed scan 2 points
    
    B = scan1 - repmat(scan1_m , 1, s1(2));
    A = scan2_n - repmat(scan2_m , 1, s2(2));
    
    [U,~,V] = svd(B*transpose(A));
    
    r = U*transpose(V)*r;% update
    t =  scan1_m - U*transpose(V)*scan2_m + t;
    
    error = sqrt(sum((scan1(1,:)-scan2_n(1,:)).^2 + (scan1(2,:)-scan2_n(2,:)).^2))/length(scan1)
    
    if error < alignment_threshold
        break;
    end
end
end



