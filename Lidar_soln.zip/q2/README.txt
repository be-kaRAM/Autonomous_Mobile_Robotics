Step1 : Load lidar_scans.mat file in the current directory
Step 2 : Open the final_main.mlx file and run it

There are total 2 functions in the code

Author : Samarth Sachan
