function [corres] = correspondence(scan1 , scan2 , max_thresh)
% returns the correspondence of points
s1 = size(scan1);
s2= size(scan2);


for i = 1:s1(2)
    dmin = inf;
    for j= 1:s2(2)
        distance = norm(scan1(:,i) - scan2(:,j));
        if distance<dmin && distance<max_thresh
            dmin = distance;
            corres(:,i)  = scan2(:,j);
        end
    end
end
end
