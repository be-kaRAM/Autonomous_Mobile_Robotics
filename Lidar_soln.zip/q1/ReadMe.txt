Step1 : Load Problem.mat file in the current directory
Step 2 : Open the solutionq1.mlx file and run it

There are total 3 functions in the code
No inbuilt function is used 
Author : Samarth Sachan
