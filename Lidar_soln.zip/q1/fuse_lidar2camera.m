function fuse_lidar2camera(Image,L_points,i)
%FUSE_LIDAR2CAMERA fuses lidar and image points
 figure
 
imshow(Image);
hold on
%scale down the points and then plots
scatter(L_points(1,:)./L_points(3,:),L_points(2,:)./L_points(3,:),1,'r','filled');
camroll(-90); % makes the image vertical
title(['Camera View ' num2str(i)]);
hold off
end

