function [t] = transformationMatrix(pose , power)

% calculates transformation matrix if power = 1
% calculates inverse of transformation matrix if power = -1

pose = pose.*[1 1 1 pi/180 pi/180 pi/180];

R_x_phi= [1 0 0;0 cos(pose(1,4)) -sin(pose(1,4));0 sin(pose(1,4)) cos(pose(1,4))];
R_y_theta= [cos(pose(1,5)) 0 sin(pose(1,5));0 1 0;-sin(pose(1,5)) 0 cos(pose(1,5))];
R_z_psi= [cos(pose(1,6)) -sin(pose(1,6)) 0;sin(pose(1,6)) cos(pose(1,6)) 0;0 0 1];

% calculates final rotation matrix
R = R_z_psi*R_y_theta*R_x_phi;

if power==1
    t = [R [pose(1);pose(2);pose(3)];0 0 0 1];
    
else
    % optimal way of calculating inverse of transformation matrix
    t = [transpose(R) -transpose(R)*[pose(1);pose(2);pose(3)];0 0 0 1];
end
end

