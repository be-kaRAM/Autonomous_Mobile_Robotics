function [Lidar_points] = relevantPoints(L)
%filters out irrelevant lidar points according to condition mentioned

% infront of camera
subset = find (L(3,:)>0);
L = L(:,subset);

%   above ground plane
subset = find(L(1,:)>0 & L(1,:)<2);
Lidar_points = L(:,subset);
 
end

